angular
  .module('HomeworkApp')
  .factory('Country', Country);

Country.$inject = ["$resource", "COUNTRIES_URL"];
function Country($resource, COUNTRIES_URL) {
  return $resource(COUNTRIES_URL, { id: '@alpha3Code' });
}