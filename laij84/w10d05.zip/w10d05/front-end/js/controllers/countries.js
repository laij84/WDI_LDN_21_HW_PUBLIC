angular
  .module("HomeworkApp")
  .controller("CountriesController", CountriesController);

CountriesController.$inject = ["Country"];

function CountriesController(Country) {
  this.all = Country.query();
}