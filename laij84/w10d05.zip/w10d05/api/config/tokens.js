module.exports = {
  'secret': 'sssh its a secret'
};